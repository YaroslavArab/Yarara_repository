# coffee_machine
Java Coffee Machine program
Hello!
This is a program which do simulation of communication with a coffee machine to make coffee for you!
Program coded with Java.
Enjoy!
if you have some issue or questions, feel free to ask me!
